#include <stdio.h>
#include <GL/gl.h>
#include <GL/glut.h>

void display()
{   
    glClearColor (1,1,1,0);
    glShadeModel(GL_SMOOTH);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    glScalef(1.1,0.8,0.1);
    glRotatef(185,0,1,0);     
    glTranslatef(-0.8,-.50,0.0);
    glRotatef(20,1,0,0);
    
   
    //Pared cara izquierda
    glBegin(GL_POLYGON);
    glColor3f(0,0,1);
    glVertex3f(0,0.4,0);
    glVertex3f(0,0.4,3);
    glVertex3f(0,1,3);
    glVertex3f(0,1,0);
    glEnd();
    //Pared de atras
    glBegin(GL_POLYGON);
    glColor3f(0,1,0);
    glVertex3f(0,0.4,0);
    glVertex3f(1.25,0.4,0);
    glVertex3f(1.25,1,0);
    glVertex3f(0,1,0);
    glEnd();
    //Pared cara derecha
    glBegin(GL_POLYGON);
    glColor3f(1,0,0);
    glVertex3f(1.25,0.4,0);
    glVertex3f(1.25,1,0);
    glVertex3f(1.25,1,3);
    glVertex3f(1.25,0.4,3);
    glEnd();
    glFlush();
   
    GLfloat ejey=-0.0f,ejex=-0.855f,cons=0.25f;
    int col=0;
    for(int y=0; y<=11;y++){
        
        ejex=-0;
        for(int x=0; x<=4;x++){
            
            
             if(col==0){
                glColor3f(0,0,0);
                col=1;
            }
            else{
                glColor3f( 1.0, 1.0, 1.0 );
                col=0;
            }
           glBegin(GL_QUADS);
                glVertex3f(ejex,0.5,ejey);
                glVertex3f(ejex+cons,0.5,ejey);
                glVertex3f(ejex+cons,0.5,ejey+cons);
                glVertex3f(ejex,0.5,ejey+cons);
            glEnd();
            glFlush();     
            ejex=ejex+cons;
        }
        ejey=ejey+cons;
    }

    glutSwapBuffers();


}

// Función para controlar teclas normales del teclado.
void keyboard(unsigned char key, int x, int y)
{
    //control de teclas que hacen referencia a Escalar y transladar el cubo en los ejes X,Y,Z.
    switch (key)
    {
    case 'q':
        exit(0);            // exit
    }
    glutPostRedisplay();
}

int main(int argc, char* argv[])
{
    //  Inicializar los parámetros GLUT y de usuario proceso
    glutInit(&argc,argv);
    // Solicitar ventana con color real y doble buffer con Z-buffer
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize (800, 800);
    glutInitWindowPosition (0, 0);
    // Crear ventana
    glutCreateWindow("Piso y paredes");
    // Habilitar la prueba de profundidad de Z-buffer
    glEnable(GL_DEPTH_TEST);
    // Funciones de retrollamada
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
     // Pasar el control de eventos a GLUT
    glutMainLoop();
    // Regresar al sistema operativo
    return 0;

}
