#include <GL/gl.h>
#include <GL/glut.h>
#include <stdlib.h>

//Creamos la pared 1
float  a=0, conz=31.25;
void pared1(){
	//Asignamos material
	GLfloat mat_ambient[] = { 0.329412f, 0.223529f, 0.027451f,1.0f };
    GLfloat mat_diffuse[] = { 0.780392f, 0.568627f, 0.113725f, 1.0f };
    GLfloat mat_specular[] = { 0.992157f, 0.941176f, 0.807843f, 1.0f };
    GLfloat shine[] = {27.8974f};
    
    
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, shine);
    glPushMatrix();
    GLfloat light_position[] = { -100, 100.0, 125.0, 1};
    glLightfv(GL_LIGHT0,GL_POSITION,light_position);
    GLfloat y=0.0f,x=-150,consx=23.214f,consz=31.25,b=0;;
      int col=0, a=0,c=10;
    for(int y1=0; y1<=3;y1++){
        x=-150;c=10;
        for(int x1=0; x1<=12;x1++){
           glBegin(GL_QUADS);
                glVertex3f(x+b,y+b,-150+a);
                glVertex3f(x+consx,y+b,-150+c);
               glVertex3f(x+consx,y+consz,-150+c);
                glVertex3f(x+b,y+consz,-150+a);
             if (c==10)
                       {
                          a=10;
                          c=0; /* code */
                       }      
                else{
                    c=10;
                    a=0;
                } 
            glEnd();
            glFlush(); 
            b=2;    
            x=x+consx;
        }
        y=y+consz;
    }
    glPopMatrix();
}

//Creamos la pared 2
void pared2(){
	//Asignamos material
	GLfloat mat_ambient[] = { 0.329412f, 0.223529f, 0.027451f,1.0f };
    GLfloat mat_diffuse[] = { 0.780392f, 0.568627f, 0.113725f, 1.0f };
    GLfloat mat_specular[] = { 0.992157f, 0.941176f, 0.807843f, 1.0f };
    GLfloat shine[] = {27.8974f};
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, shine);
    glPushMatrix();
    GLfloat light_position[] = { -100, 100.0, 125.0, 1};
    glLightfv(GL_LIGHT0,GL_POSITION,light_position);
    GLfloat y=-150.0f,x=-150,consx=23.214f,consz=31.25,b=0;;
    for(int y1=0; y1<=8;y1++){
        x=-150,a=0;
        for(int x1=0; x1<=12;x1++){
           glBegin(GL_QUADS);
                glVertex3f(x+b,0,y+b);
                glVertex3f(x+consx,0,y+b);
               glVertex3f(x+consx,0,y+consz);
                glVertex3f(x+b,0,y+consz);
            glEnd();
            glFlush(); 
            b=2;    
            x=x+consx;
        }
        y=y+consz;
    }
    glPopMatrix();
}

void cubo(){
	//Asignamos el material
	GLfloat light_position[] = { -50, 150.0, 125.0, 1};
    GLfloat mat_ambient[] = { 0.24725f, 0.1995f, 0.0745f, 1.0f };
    GLfloat mat_diffuse[] = { 0.75164f, 0.60648f, 0.22648f, 1.0f };
    GLfloat mat_specular[] = { 0.628281f, 0.555802f, 0.366065f, 1.0f };
    GLfloat mat_shininess[] = { 0.4f };
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
	glTranslatef(0,75,110);
    glPushMatrix();
    glLightfv(GL_LIGHT0,GL_POSITION,light_position);  
    glTranslatef(0,0,0);
    //creamos el cubo
    glutSolidCube(50);
    glPopMatrix();
}

void esfera(){
	//Asignamos el material
	GLfloat mat_ambient[] = { 0.005,0.0f,0.0f };
    GLfloat mat_diffuse[] = { 0.5f,0.4f,0.4f, 1.0f };
    GLfloat mat_specular[] = { 0.7f,0.04f,0.04f };
    GLfloat shine[] = {0.078125};
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, shine);
	glPushMatrix();
	GLfloat light_position[] = { -50, 150.0, 125.0, 1};
    glLightfv(GL_LIGHT0,GL_POSITION,light_position);
    glTranslatef(-100,0,0);
    //Creamos la esfera
    glutSolidSphere(40,40,40);
    glPopMatrix();
}

void cono(){
	//Asignamos el material
	GLfloat mat_ambient[] = { 0.0f, 0.1f, 0.06f,1.0f };
    GLfloat mat_diffuse[] = { 0.0f, 0.50980392f, 0.50980392f, 1.0f };
    GLfloat mat_specular[] = { 0.50196078f, 0.50196078f, 0.50196078f, 1.0f };
    GLfloat shine[] = {0-25};
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, shine);
	glPushMatrix();
	GLfloat light_position[] = { -50, 150.0, 25.0, 1};
    glLightfv(GL_LIGHT0,GL_POSITION,light_position);
    glTranslatef(100,-25,0);
    glRotatef(-90,1,0,0);
    //Creamos el cono
    glutSolidCone(40,60,10,25);
    glPopMatrix();
}

void init(void)
{
	glClearColor(1,1,1,0);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glDepthFunc(GL_LESS);
    glEnable(GL_DEPTH_TEST);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    glShadeModel(GL_SMOOTH);
}

void reshape(int w, int h)
{
    glViewport(0, 0,  (GLsizei) w, (GLsizei) h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-200, 200, -200, 200, -200, 200);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode( GL_MODELVIEW_MATRIX );
    glLoadIdentity();
    
	//rotamos el dibujo
    glRotatef(20,1,0,0);
    glRotatef(-10,0,1,0);
    
    //dibujo de las paredes
    pared1();
    pared2();

    //dibujamos las figuras
    cubo();
	esfera();
    cono();

    glFlush();
}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize (800, 600);
    glutInitWindowPosition (60, 60);
    glutCreateWindow ("Figuras");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMainLoop();

    return 0;
}
