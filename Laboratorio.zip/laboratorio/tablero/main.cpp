#include <stdio.h>
#include <GL/gl.h>
#include <GL/glut.h>

void display()
{   
    glClearColor (0,0,0.2,0);
    glShadeModel(GL_SMOOTH);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    //PREPARANDO ARIABLES PARA EL TABLERO
    glPushMatrix();
    glRotatef(50,8,0,0);
    GLfloat ejey=-1.0f,ejex=-0.855f,cons=0.25f;
    int col=0;
    for(int y=0; y<=6;y++){
        
        ejex=-0.90;
        for(int x=0; x<=6;x++){
            
            
             if(col==0){
                glColor3f(0,0,0);
                col=1;
            }
            else{
                glColor3f( 1.0, 1.0, 1.0 );
                col=0;
            }
           glBegin(GL_QUADS);
                glVertex3f(ejex,ejey,0);
                glVertex3f(ejex+cons,ejey,0);
                glVertex3f(ejex+cons,ejey+cons,0);
                glVertex3f(ejex,ejey+cons,0);
            
            glEnd();
            glFlush();     
            ejex=ejex+cons;
        }
        ejey=ejey+cons;
    }
    glPopMatrix();
    glutSwapBuffers();


}


// Función para controlar teclas normales del teclado.
void keyboard(unsigned char key, int x, int y)
{
    //control de teclas que hacen referencia a Escalar y transladar el cubo en los ejes X,Y,Z.
    switch (key)
    {
   
    case 'q':
        exit(0);            // exit
    }
    glutPostRedisplay();
}

int main(int argc, char* argv[])
{

    //  Inicializar los parámetros GLUT y de usuario proceso
    glutInit(&argc,argv);
    // Solicitar ventana con color real y doble buffer con Z-buffer
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize (800, 800);
    glutInitWindowPosition (0, 0);
    // Crear ventana
    glutCreateWindow("tablero de damas");
    // Habilitar la prueba de profundidad de Z-buffer
    glEnable(GL_DEPTH_TEST);
    // Funciones de retrollamada
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    // Pasar el control de eventos a GLUT
    glutMainLoop();

    // Regresar al sistema operativo
    return 0;

}
